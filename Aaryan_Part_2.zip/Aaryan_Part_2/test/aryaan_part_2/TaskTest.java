package aryaan_part_2;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.Test;

public class TaskTest {
    public TaskTest() {
    }

   
    @Test
    public void testCheckTaskDescription_Success() {
        Task task = new Task();
        assertTrue(task.checkTaskDescription("Valid description")); // Less than 50 characters
    }

    
    @Test
    public void testCheckTaskDescription_Failure() {
        Task task = new Task();
        assertFalse(task.checkTaskDescription("This description is longer than 50 characters and hence invalid.")); // More than 50 characters
    }

    
    @Test
    public void testCreateTaskID() {
        Task task = new Task();
        
        task.setNumberOfTasks(2);
        task.getStrTaskName()[0] = "login feature";
        task.getStrDevelopFirstName()[0] = "Robbyn";
        task.getStrDeveloperLastName()[0] = "Harrison";
        assertEquals("LO:0:BYN", task.createTaskID(0)); 
    }

    @Test
    public void testCreateTaskID_SecondCase() {
        Task task = new Task();
        task.setNumberOfTasks(2);
        task.getStrTaskName()[0] = "add task feature";
        task.getStrDevelopFirstName()[0] = "Mike";
        task.getStrDeveloperLastName()[0] = "Smith";
        assertEquals("AD:0:IKE", task.createTaskID(0)); 
    }

    @Test
    public void testAccumulateTotalHours() {
        Task task = new Task();
        task.setNumberOfTasks(2);
        task.getIntTaskDuration()[0] = 8;
        task.getIntTaskDuration()[1] = 10;
        assertEquals(18, task.returnTotalHours(1)); 
    }
}
